#include <stdio.h>
#include <stdlib.h>

int main(void) {
  system("cls");

  printf(" -------------------------\n");
  printf(" |  |  |  |  |  |  |  |  |\n");
  printf(" -------------------------\n");
  printf(" |  |  |  |  |  |  |  |  |\n");
  printf(" -------------------------\n");
  printf(" |  |  |  |  |  |  |  |  |\n");
  printf(" -------------------------\n");
  printf(" |  |  |  |○|●|  |  |  |\n");
  printf(" -------------------------\n");
  printf(" |  |  |  |●|○|  |  |  |\n");
  printf(" -------------------------\n");
  printf(" |  |  |  |  |  |  |  |  |\n");
  printf(" -------------------------\n");
  printf(" |  |  |  |  |  |  |  |  |\n");
  printf(" -------------------------\n");
  printf(" |  |  |  |  |  |  |  |  |\n");
  printf(" -------------------------\n");

  return EXIT_SUCCESS;
}